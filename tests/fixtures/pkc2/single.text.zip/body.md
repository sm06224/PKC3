# 議事録

![図](asset:ast-shared)

- 決定事項
